Binary2BCD 二进转十进制，可以仿真
key_filter 可以仿真 按键消抖
smg_demo 没有仿真

